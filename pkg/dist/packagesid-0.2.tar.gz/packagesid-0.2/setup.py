from setuptools import setup #,find_packages
setup(name="packagesid",
version="0.2",
description="This is Sidharth's package",
long_description="This is a very long description",
author="Sidharth",
packages=['packagesid'],
install_requires=[])