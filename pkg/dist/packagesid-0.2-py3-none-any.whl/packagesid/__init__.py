class Achha:
    def __init__(self) -> None:
        print("Constructor ban gya")
    def achhafunc(number):
        print("This is a function")
        return number